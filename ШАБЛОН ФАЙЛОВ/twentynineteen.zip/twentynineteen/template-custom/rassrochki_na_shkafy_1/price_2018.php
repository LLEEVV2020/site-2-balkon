
<div class="template price_2018">

    <div class="container">
        <div class="h2">ЦЕНЫ НА БАЛКОНЫ В ЛУЧШИХ КОМПАНИЯХ 2018 ГОДА</div>
        <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/price_2018.png" alt="">
    </div> 
</div>