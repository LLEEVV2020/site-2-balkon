
            <div class="b_windownow_bg rast_windownow_bg">
    
                <div class="container">
    
                    <div class="flex-container">
                        <div class="b_windownow_man"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/rasr_gerl2.png" alt=""></div>
                        <div class="b_windownow_block">
                            <h4>ШКАФ БЕСПЛАТНО!</h4>
                            
                            <p>Верните все деньги за новый шкаф, оформив дисконтную карту!</p>  

                            <a href="#" data-toggle="modal" data-target="#kupitDeshevle"class="b_windownow__btn">ОФОРМИТЬ</a>
                                    
                        </div>
                        
                    </div> 
    
                </div><!-- /.container -->
    
            </div>