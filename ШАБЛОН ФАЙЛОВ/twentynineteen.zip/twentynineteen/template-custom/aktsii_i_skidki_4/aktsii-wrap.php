    <div class="aktsii-wrap">

            <div class="container">
                <h2>ВЫГОДНЫЕ ЦЕНЫ НА ОСТЕКЛЕНИЕ БАЛКОНОВ!</h2>
            </div> 

            <div class="action-item">
                <div class="container">
                    <div class="flex-container">
                        <div class="item-text">
                            <div class="h4">
                                <i>1</i>
                                <span> <span >КАЖДЫЙ ВТОРОЙ</span>  БАЛКОН В ПОДАРОК</span>
                            </div>
                            <p>Компания «Балконы Цены» предлагает уникальную акцию: заказывая одновременно 2 балкона или лоджии, Вы получаете остекление третьего балкона абсолютно бесплатно.</p>
                        </div>
                        <div class="item-img" style="    flex-basis: 462px;
    max-width: 462px;"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/aktsii-i-skidki-1.png" alt=""></div>
                    </div>
                </div>
            </div>
           
            <div class="action-item">
                <div class="container">
                    <div class="flex-container">
                        <div class="item-text">

                            <div class="h4">
                                <i>2</i>
                                <span><span> МОСКИТНАЯ СЕТКА</span> В ПОДАРОК</span>
                            </div>
                            <p>Компания «Балконы Цены» предлагает уникальную акцию: при заказе балкона или лоджии с двумя поворотно-откидными створками москитная сетка в подарок!</p>
                        

                        </div>
                        <div class="item-img"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/aktsii-i-skidki-2.png" alt=""></div>
                    </div>
                </div>
            </div>
            <div class="action-item"  style="padding-bottom: 0; overflow: hidden;">
                <div class="container">
                    <div class="flex-container">
                        <div class="item-text">
                            <div class="h4">
                                <i>3</i>
                                <span><span>ВЕРНЕМ ДЕНЬГИ</span> НАЗАД</span>
                            </div>
                            <p  >Компания Компания «Балконы Цены» предлагает уникальную акцию: при заказе балкона или лоджии с двумя поворотно-откидными створками москитная сетка в подарок!</p>

                        </div>
                        <div class="item-img"><img style="transform: translateY(9px);" src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/aktsii-i-skidki-3.png" alt=""></div>

                    </div>
                </div>
            </div>


            <div class="action-item">
                <div class="container">
                    <div class="h3">УЗНАЙТЕ, КАКАЯ АКЦИЯ НАИБОЛЕЕ ВЫГОДНАЯ ДЛЯ ВАС ПО ТЕЛЕФОНУ: <span>8 (495) 000-00-00</span></div>
                    <p>Примечание: акции не суммируются друг с другом, т.е. можно выбрать только одну!</p>
                </div>
            </div>

        </div>