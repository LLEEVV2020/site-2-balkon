        <div class="template es10_repairs_balcony">
            <div class="container">
                <div class="repairs-wrapper">
                    <div class="h2">РЕМОНТ БАЛКОНОВ
                        И ЛОДЖИЙ</div>
                    <div class="item">
                        <div class="name">Установка крыши</div>
                        <div class="discount">980 Р</div>
                        <div class="price">1500 Р</div>
                    </div>
                    <div class="item">
                        <div class="name">Остекление</div>
                        <div class="discount">2310 Р</div>
                        <div class="price">2500 Р</div>
                    </div>
                    <div class="item">
                        <div class="name">Кладка парапета</div>
                        <div class="discount">440 Р</div>
                        <div class="price">870 Р</div>
                    </div>
                    <div class="item">
                        <div class="name">Вынос балкона</div>
                        <div class="discount">430 Р</div>
                        <div class="price">750 Р</div>
                    </div>
                    <div class="item">
                        <div class="name">Утепление стен</div>
                        <div class="discount">410 Р</div>
                        <div class="price">650 Р</div>
                    </div>
                    <div class="item">
                        <div class="name">Отделка</div>
                        <div class="discount">790 Р</div>
                        <div class="price">1100 Р</div>
                    </div>
                    <div class="item">
                        <div class="name">Укладка пола</div>
                        <div class="discount">510 Р</div>
                        <div class="price">980 Р</div>
                    </div>
                    <p>Ваша выгода составляет : <span>3750</span><span>Р</span></p>
                </div>
            </div>  

        </div>