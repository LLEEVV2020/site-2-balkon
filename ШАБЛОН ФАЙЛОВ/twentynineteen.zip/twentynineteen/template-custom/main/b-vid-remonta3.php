<div class="wrap-b-vid-remonta" id="b-vid">
    <div class="b-vid-remonta _white">


        <div class="container">
            <div  class="h2">ВСТРОЕННЫЕ ШКАФЫ ПО НИЗКИМ ЦЕНАМ</div>

            <div class="b-vid-remonta__block">
                <div class="b-vid-remonta__item">
                    <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/1.jpg" /> </div>
                    <div class="b-vid-remonta__item_ttl"><span>ШКАФ-КУПЕ  С ФОТОПЕЧАТЬЮ</span></div>
                    <div class="b-vid-remonta__item_spisok">
                        <ul class="check">
                            <li>Готовый / на заказ</li>
                            <li>Корпусный / встроенный</li>    
                            <li>С зеркалом / без зеркала</li>
                            <li>Для прихожей, спальни и т.д.</li>
                            <li>Любого размера и наполнения</li>
                        </ul>

                    </div>
                    <div class="b-vid-remonta__item_price">
                        <div class="b-vid-remonta__price_old">12500</div>
                        <div class="b-vid-remonta__price_new">от 7100 р.</div>
                    </div>
                    <div class="b-vid-remonta__item_btn">
                        <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                    </div>
                </div>
                <div class="b-vid-remonta__item">
                    <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/2.jpg" /> </div>
                    <div class="b-vid-remonta__item_ttl"><span>ШКАФ С ФОТОПЕЧАТЬЮ</span></div>
                    <div class="b-vid-remonta__item_spisok">
                        <ul class="check">
                            <li>Готовый / на заказ</li>
                            <li>Корпусный / встроенный</li>    
                            <li>С зеркалом / без зеркала</li>
                            <li>Для прихожей, спальни и т.д.</li>
                            <li>Любого размера и наполнения</li>
                        </ul>

                    </div>
                    <div class="b-vid-remonta__item_price">
                        <div class="b-vid-remonta__price_old">12500</div>
                        <div class="b-vid-remonta__price_new">от 7100 р.</div>
                    </div>
                    <div class="b-vid-remonta__item_btn">
                        <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                    </div>
                </div>
                       
                       <div class="b-vid-remonta__item">
                        <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/3.jpg" /> </div>
                        <div class="b-vid-remonta__item_ttl"><span>ВСТРОЕННЫЙ ШКАФ-КУПЕ</span></div>
                        <div class="b-vid-remonta__item_spisok">
                            <ul class="check">
                                <li>Готовый / на заказ</li>
                                <li>Корпусный / встроенный</li>    
                                <li>С зеркалом / без зеркала</li>
                                <li>Для прихожей, спальни и т.д.</li>
                                <li>Любого размера и наполнения</li>
                            </ul>

                        </div>
                        <div class="b-vid-remonta__item_price">
                            <div class="b-vid-remonta__price_old">12500</div>
                            <div class="b-vid-remonta__price_new">от 7100 р.</div>
                        </div>
                        <div class="b-vid-remonta__item_btn">
                            <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                        </div>
                    </div>
                
                      
                    <div class="b-vid-remonta__item">
                        <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/4.jpg" /> </div>
                        <div class="b-vid-remonta__item_ttl"><span>БЕЛЫЙ ШКАФ</span></div>
                        <div class="b-vid-remonta__item_spisok">
                            <ul class="check">
                                <li>Готовый / на заказ</li>
                                <li>Корпусный / встроенный</li>    
                                <li>С зеркалом / без зеркала</li>
                                <li>Для прихожей, спальни и т.д.</li>
                                <li>Любого размера и наполнения</li>
                            </ul>

                        </div>
                        <div class="b-vid-remonta__item_price">
                            <div class="b-vid-remonta__price_old">12500</div>
                            <div class="b-vid-remonta__price_new">от 7100 р.</div>
                        </div>
                        <div class="b-vid-remonta__item_btn">
                            <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                        </div>
                    </div>
                    
                    
                    <div class="b-vid-remonta__item">
                        <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/5.jpg" /> </div>
                        <div class="b-vid-remonta__item_ttl"><span>ШКАФ-КУПЕ С ГЛЯНЦЕВЫМИ СТВОРКАМИ</span></div>
                        <div class="b-vid-remonta__item_spisok">
                            <ul class="check">
                                <li>Готовый / на заказ</li>
                                <li>Корпусный / встроенный</li>    
                                <li>С зеркалом / без зеркала</li>
                                <li>Для прихожей, спальни и т.д.</li>
                                <li>Любого размера и наполнения</li>
                            </ul>

                        </div>
                        <div class="b-vid-remonta__item_price">
                            <div class="b-vid-remonta__price_old">12500</div>
                            <div class="b-vid-remonta__price_new">от 7100 р.</div>
                        </div>
                        <div class="b-vid-remonta__item_btn">
                            <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                        </div>
                    </div>
                    
                    
                    <div class="b-vid-remonta__item">
                        <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/6.jpg" /> </div>
                        <div class="b-vid-remonta__item_ttl"><span>ШКАФ-КУПЕ ТРЕХДВЕРНЫЙ С ПОЛКАМИ</span></div>
                        <div class="b-vid-remonta__item_spisok">
                            <ul class="check">
                                <li>Готовый / на заказ</li>
                                <li>Корпусный / встроенный</li>    
                                <li>С зеркалом / без зеркала</li>
                                <li>Для прихожей, спальни и т.д.</li>
                                <li>Любого размера и наполнения</li>
                            </ul>

                        </div>
                        <div class="b-vid-remonta__item_price">
                            <div class="b-vid-remonta__price_old">12500</div>
                            <div class="b-vid-remonta__price_new">от 7100 р.</div>
                        </div>
                        <div class="b-vid-remonta__item_btn">
                            <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                        </div>
                    </div>
                    
                    <div class="b-vid-remonta__item">
                        <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/7.jpg" /> </div>
                        <div class="b-vid-remonta__item_ttl"><span>ШКАФ С СОВРЕМЕННЫМ ДИЗАЙНОМ</span></div>
                        <div class="b-vid-remonta__item_spisok">
                            <ul class="check">
                                <li>Готовый / на заказ</li>
                                <li>Корпусный / встроенный</li>    
                                <li>С зеркалом / без зеркала</li>
                                <li>Для прихожей, спальни и т.д.</li>
                                <li>Любого размера и наполнения</li>
                            </ul>

                        </div>
                        <div class="b-vid-remonta__item_price">
                            <div class="b-vid-remonta__price_old">12500</div>
                            <div class="b-vid-remonta__price_new">от 7100 р.</div>
                        </div>
                        <div class="b-vid-remonta__item_btn">
                            <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                        </div>
                    </div>
                    
                     <div class="b-vid-remonta__item">
                        <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/8.jpg" /> </div>
                        <div class="b-vid-remonta__item_ttl"><span>СТИЛЬНЫЙ ГЛЯНЦЕВЫЙ ШКАФ</span></div>
                        <div class="b-vid-remonta__item_spisok">
                            <ul class="check">
                                <li>Готовый / на заказ</li>
                                <li>Корпусный / встроенный</li>    
                                <li>С зеркалом / без зеркала</li>
                                <li>Для прихожей, спальни и т.д.</li>
                                <li>Любого размера и наполнения</li>
                            </ul>

                        </div>
                        <div class="b-vid-remonta__item_price">
                            <div class="b-vid-remonta__price_old">12500</div>
                            <div class="b-vid-remonta__price_new">от 7100 р.</div>
                        </div>
                        <div class="b-vid-remonta__item_btn">
                            <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                        </div>
                    </div>
                    
                    
                     <div class="b-vid-remonta__item">
                        <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/9.jpg" /> </div>
                        <div class="b-vid-remonta__item_ttl"><span>ШКАФ ДЛЯ ПРИХОЖЕЙ</span></div>
                        <div class="b-vid-remonta__item_spisok">
                            <ul class="check">
                                <li>Готовый / на заказ</li>
                                <li>Корпусный / встроенный</li>    
                                <li>С зеркалом / без зеркала</li>
                                <li>Для прихожей, спальни и т.д.</li>
                                <li>Любого размера и наполнения</li>
                            </ul>

                        </div>
                        <div class="b-vid-remonta__item_price">
                            <div class="b-vid-remonta__price_old">12500</div>
                            <div class="b-vid-remonta__price_new">от 7100 р.</div>
                        </div>
                        <div class="b-vid-remonta__item_btn">
                            <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                        </div>
                    </div>
                    
                     <div class="b-vid-remonta__item">
                        <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/10.jpg" /> </div>
                        <div class="b-vid-remonta__item_ttl"><span>ШКАФ-КУПЕ ДЛЯ ПРИХОЖЕЙ</span></div>
                        <div class="b-vid-remonta__item_spisok">
                            <ul class="check">
                                <li>Готовый / на заказ</li>
                                <li>Корпусный / встроенный</li>    
                                <li>С зеркалом / без зеркала</li>
                                <li>Для прихожей, спальни и т.д.</li>
                                <li>Любого размера и наполнения</li>
                            </ul>

                        </div>
                        <div class="b-vid-remonta__item_price">
                            <div class="b-vid-remonta__price_old">12500</div>
                            <div class="b-vid-remonta__price_new">от 7100 р.</div>
                        </div>
                        <div class="b-vid-remonta__item_btn">
                            <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                        </div>
                    </div>
                      
                       <div class="b-vid-remonta__item">
                        <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/11.jpg" /> </div>
                        <div class="b-vid-remonta__item_ttl"><span>УГЛОВОЙ ШКАФ ДЛЯ ПРИХОЖЕЙ</span></div>
                        <div class="b-vid-remonta__item_spisok">
                            <ul class="check">
                                <li>Готовый / на заказ</li>
                                <li>Корпусный / встроенный</li>    
                                <li>С зеркалом / без зеркала</li>
                                <li>Для прихожей, спальни и т.д.</li>
                                <li>Любого размера и наполнения</li>
                            </ul>

                        </div>
                        <div class="b-vid-remonta__item_price">
                            <div class="b-vid-remonta__price_old">12500</div>
                            <div class="b-vid-remonta__price_new">от 7100 р.</div>
                        </div>
                        <div class="b-vid-remonta__item_btn">
                            <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                        </div>
                    </div>
                    
                       <div class="b-vid-remonta__item">
                        <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/12.jpg" /> </div>
                        <div class="b-vid-remonta__item_ttl"><span>ФУНКЦИОНАЛЬНЫЙ ШКАФ ДЛЯ ПРИХОЖЕЙ</span></div>
                        <div class="b-vid-remonta__item_spisok">
                            <ul class="check">
                                <li>Готовый / на заказ</li>
                                <li>Корпусный / встроенный</li>    
                                <li>С зеркалом / без зеркала</li>
                                <li>Для прихожей, спальни и т.д.</li>
                                <li>Любого размера и наполнения</li>
                            </ul>

                        </div>
                        <div class="b-vid-remonta__item_price">
                            <div class="b-vid-remonta__price_old">12500</div>
                            <div class="b-vid-remonta__price_new">от 7100 р.</div>
                        </div>
                        <div class="b-vid-remonta__item_btn">
                            <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                        </div>
                    </div>
                    
                       <div class="b-vid-remonta__item">
                        <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/13.jpg" /> </div>
                        <div class="b-vid-remonta__item_ttl"><span>РАСПАШНОЙ ШКАФ ДЛЯ ГОСТИНОЙ</span></div>
                        <div class="b-vid-remonta__item_spisok">
                            <ul class="check">
                                <li>Готовый / на заказ</li>
                                <li>Корпусный / встроенный</li>    
                                <li>С зеркалом / без зеркала</li>
                                <li>Для прихожей, спальни и т.д.</li>
                                <li>Любого размера и наполнения</li>
                            </ul>

                        </div>
                        <div class="b-vid-remonta__item_price">
                            <div class="b-vid-remonta__price_old">12500</div>
                            <div class="b-vid-remonta__price_new">от 7100 р.</div>
                        </div>
                        <div class="b-vid-remonta__item_btn">
                            <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                        </div>
                    </div>
                    
                      
                       <div class="b-vid-remonta__item">
                        <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/14.jpg" /> </div>
                        <div class="b-vid-remonta__item_ttl"><span>ШКАФ-КУПЕ ДЛЯ ГОСТИНОЙ</span></div>
                        <div class="b-vid-remonta__item_spisok">
                            <ul class="check">
                                <li>Готовый / на заказ</li>
                                <li>Корпусный / встроенный</li>    
                                <li>С зеркалом / без зеркала</li>
                                <li>Для прихожей, спальни и т.д.</li>
                                <li>Любого размера и наполнения</li>
                            </ul>

                        </div>
                        <div class="b-vid-remonta__item_price">
                            <div class="b-vid-remonta__price_old">12500</div>
                            <div class="b-vid-remonta__price_new">от 7100 р.</div>
                        </div>
                        <div class="b-vid-remonta__item_btn">
                            <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                        </div>
                    </div>
                      
                       <div class="b-vid-remonta__item">
                        <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/15.jpg" /> </div>
                        <div class="b-vid-remonta__item_ttl"><span>ШКАФ-КУПЕ ДЛЯ СПАЛЬНИ</span></div>
                        <div class="b-vid-remonta__item_spisok">
                            <ul class="check">
                                <li>Готовый / на заказ</li>
                                <li>Корпусный / встроенный</li>    
                                <li>С зеркалом / без зеркала</li>
                                <li>Для прихожей, спальни и т.д.</li>
                                <li>Любого размера и наполнения</li>
                            </ul>

                        </div>
                        <div class="b-vid-remonta__item_price">
                            <div class="b-vid-remonta__price_old">12500</div>
                            <div class="b-vid-remonta__price_new">от 7100 р.</div>
                        </div>
                        <div class="b-vid-remonta__item_btn">
                            <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                        </div>
                    </div>
                    
                     
                       <div class="b-vid-remonta__item">
                        <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/16.jpg" /> </div>
                        <div class="b-vid-remonta__item_ttl"><span>РЕТРО-ШКАФ ДЛЯ СПАЛЬНИ</span></div>
                        <div class="b-vid-remonta__item_spisok">
                            <ul class="check">
                                <li>Готовый / на заказ</li>
                                <li>Корпусный / встроенный</li>    
                                <li>С зеркалом / без зеркала</li>
                                <li>Для прихожей, спальни и т.д.</li>
                                <li>Любого размера и наполнения</li>
                            </ul>

                        </div>
                        <div class="b-vid-remonta__item_price">
                            <div class="b-vid-remonta__price_old">12500</div>
                            <div class="b-vid-remonta__price_new">от 7100 р.</div>
                        </div>
                        <div class="b-vid-remonta__item_btn">
                            <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                        </div>
                    </div>
                    
                       <div class="b-vid-remonta__item">
                        <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/17.jpg" /> </div>
                        <div class="b-vid-remonta__item_ttl"><span>ШКАФ ДЛЯ СПАЛЬНИ</span></div>
                        <div class="b-vid-remonta__item_spisok">
                            <ul class="check">
                                <li>Готовый / на заказ</li>
                                <li>Корпусный / встроенный</li>    
                                <li>С зеркалом / без зеркала</li>
                                <li>Для прихожей, спальни и т.д.</li>
                                <li>Любого размера и наполнения</li>
                            </ul>

                        </div>
                        <div class="b-vid-remonta__item_price">
                            <div class="b-vid-remonta__price_old">12500</div>
                            <div class="b-vid-remonta__price_new">от 7100 р.</div>
                        </div>
                        <div class="b-vid-remonta__item_btn">
                            <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                        </div>
                    </div>
                    
                       <div class="b-vid-remonta__item">
                        <div class="b-vid-remonta__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/vid-remonta/18.jpg" /> </div>
                        <div class="b-vid-remonta__item_ttl"><span>СТИЛЬНЫЙ ШКАФ ДЛЯ СПАЛЬНИ</span></div>
                        <div class="b-vid-remonta__item_spisok">
                            <ul class="check">
                                <li>Готовый / на заказ</li>
                                <li>Корпусный / встроенный</li>    
                                <li>С зеркалом / без зеркала</li>
                                <li>Для прихожей, спальни и т.д.</li>
                                <li>Любого размера и наполнения</li>
                            </ul>

                        </div>
                        <div class="b-vid-remonta__item_price">
                            <div class="b-vid-remonta__price_old">12500</div>
                            <div class="b-vid-remonta__price_new">от 7100 р.</div>
                        </div>
                        <div class="b-vid-remonta__item_btn">
                            <a data-toggle="modal" data-target="#kupitDeshevle" class="red-button-radius">Рассчитать</a>
                        </div>
                    </div>
                    

            </div>

            <p>Более 500 моделей шкафов в нашем каталоге! Предоставляется по запросу. Звоните – привезем его вам быстро и абсолютно бесплатно!</p>

        </div>
    </div>
</div>