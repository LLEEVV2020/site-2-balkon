
        <div class="es7_balcons template">
            <div class="container">
                    <div class="h2">ДОПОЛНИТЕЛЬНАЯ СКИДКА 5% ПРИ ЗАКАЗЕ ЧЕРЕЗ САЙТ</div>
                
                <form action="php/mail.php" method="POST">
                    <div class="b-sms_input b-sms_input_tel form-group">
                        <input type="text" class="phonemask input-phone" data-validation="required" placeholder="Ваш телефон" id="form_text_11" name="phone" value="" size="0">
                    </div>
                    <div class="b-sms_input b-sms_input_tel form-group">
                        <input type="text" class="" data-validation="required" placeholder="Ваше имя" id="form_text_11" name="phone" value="" size="0">
                    </div>
                    <div class="block-sketch-submit">
                        <div class="sketch" title="Прикрепить файл">
                        
                            <input  onchange="readURL(this);" size="0" type="file"><i class="sketch-text"><span>Загрузить</span>
                                эскизы</i> 
                        </div>
                        <button class="red-button" type="submit">РАССЧИТАТЬ</button>
    
                    </div>
                </form>
                <div class="text">Если у Вас нет эскизов, впишите номер телефона и менеджер перезвонит Вам для
                    выяснения размеров!</div>
                <p>Оставляя свои контактные данные, вы подтверждаете свое совершеннолетие,
                    соглашаетесь на обработку персональных данных в соответствии с Правовой информацией</p>
            </div>
        </div><!-- /.es13_14 -->