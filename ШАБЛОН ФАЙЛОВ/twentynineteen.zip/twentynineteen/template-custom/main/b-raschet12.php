 <div class="b-way">
            <div class="container">
                <div class="h2">ПОЧЕМУ ЗАКАЗЫВАТЬ В «КОМПАНИИ» ВСЕГДА ЛУЧШЕ?</div>

                <div class="b-way__item">
                    <div class="b-way__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/way1.png" alt="Собственное производство" /></div>
                    <div class="b-way__item_ttl">СОБСТВЕННОЕ ПРОИЗВОДСТВО </div>
                    <div class="b-way__item_info">Компания «Компания» имеет собственное производство, что позволяет разрабатывать и создавать абсолютно любые шкафы! Это позволяет избежать ненужных наценок, без которых дилеры обойтись не смогут.
                            </div>
                </div>
                <div class="b-way__item">
                    <div class="b-way__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/way2.png" alt="Качественные материалы" /></div>
                    <div class="b-way__item_ttl">КАЧЕСТВЕННЫЕ МАТЕРИАЛЫ </div>
                    <div class="b-way__item_info">Все модели мебели нашей компании выполнены из качественных материалов, что гарантирует комфорт и длительную эксплуатацию.
                            </div>
                </div>
                <div class="b-way__item">
                    <div class="b-way__item_pict"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/way3.png" alt="Выгодные условия" /></div>
                    <div class="b-way__item_ttl">ВЫГОДНЫЕ УСЛОВИЯ </div>
                    <div class="b-way__item_info">В нашей компании работают высококлассные мастера, которые профессионально выполнят установку шкафа любой сложности. <br>
Узнайте расценки прямо сейчас: <abbr title="<?php if(empty(get_option('my_phone')) ){
                                                          echo "8 (495) 106-48-55";
                                                      }
                                                      else{
                                                          echo get_option('my_phone'); 
                                                      } ?>"><?php if(empty(get_option('my_phone')) ){
                                                          echo "8 (495) 106-48-55";
                                                      }
                                                      else{
                                                          echo get_option('my_phone'); 
                                                      } ?></abbr>
                    </div>
                </div>
            </div>
        </div>
        <!--b-way-->