<div class="es7">
            
    <div class="container flex-container ">

        <div class="item">

            <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/es7_ico1.png" alt="">
            <div class="item-text">
                <h4 class="media-heading">Бесплатный замер</h4>
                <div>Замерщик «Компании» в удобное для вас время произведет замер и точный расчет стоимости вашего заказа. Также возможно заключение договора на дому.</div>        
            </div>
            

        </div>

        <div class="item">

            <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/es7_ico2.png" alt="">
            <div class="item-text">
                <h4 class="media-heading">Рассрочка 0%</h4>
                <div>Сделайте заказ прямо сейчас и воспользуйтесь беспроцентной рассрочкой сроком до 12 месяцев с минимальным первоначальным взносом.</div>       
            </div>
            

        </div>

    </div><!-- /.container -->

</div>