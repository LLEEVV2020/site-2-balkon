        <!-- Самый верхний блок -->
        <div class="es1 _main template">
            <div class="container">
                <div class="es1__pict"></div>
                <div class="es1__block">
                    <div class="es1-wrapper-decor">
                        <h1><span>ОСТЕКЛЕНИЕ</span>
                        <span>БАЛКОНОВ</span>
                        <span>ВСЕГО ЗА</span></h1>
                        <h2>2310 Р </h2>
                        <p>*стоимость действительна только 7 дней</p>
                   </div>
                    
                </div>

                <div class="es1-flex-wrap">
                    <div class="b-top__zamer block-calculate"  data-toggle="modal" data-target="#kupitDeshevle">
                        <div class="b-top__zamer_ruler "></div>
                        <div class="b-top__zamer_txt"><span>РАССЧИТАТЬ</span><br>
                            по самой низкой цене</div>
                    </div>
                    <div class="name-abs">
                        <span>Мастер</span>
                        <span>Алексей Петров</span>
                    </div>
                    <div class="b-top__zamer"  data-toggle="modal" data-target="#kupitDeshevle">
                        <div class="b-top__zamer_ruler "></div>
                        <div class="b-top__zamer_txt"><span>БЕСПЛАТНЫЙ</span><br>
                            выезд замерщика</div>
                    </div>
                </div>

            </div>
        </div>
        <!--/ Самый верхний блок -->