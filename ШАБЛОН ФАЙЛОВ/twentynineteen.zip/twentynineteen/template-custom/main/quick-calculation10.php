 <!-- quick-calculation10 -->
        <div class="quick-calculation">
            <div class="container">
                <div class="h2">ТАКЖЕ ВЫ МОЖЕТЕ ЗАКАЗАТЬ:</div>
                <div class="flex-container">
                    <div class="item item-1">
                        <div class="es2_but" data-toggle="modal" data-target="#kupitDeshevle">ЯЩИКИ – ОТ 220 РУБ.</div>
                    </div>
                    <div class="item item-2">
                        <div class="es2_but" data-toggle="modal" data-target="#kupitDeshevle">ВЕШАЛКИ – ОТ 90 РУБ.</div>
                    </div>
                    <div class="item item-3">
                        <div class="es2_but" data-toggle="modal" data-target="#kupitDeshevle">ШТАНГИ – ОТ 790 РУБ.</div>
                    </div>
                </div>
            </div>
            
        </div>