<!--<div class="es18_bg">
            <div class="container">

                <div class="flex-container">

                    <h3>ШКАФЫ И КУХНИ ПО НИЗКИМ ЦЕНАМ </h3>
                    <i class="angle-angle"></i>
                    <a href="//<?php echo $_SERVER['SERVER_NAME']; ?>">Шкафы цены</a>
                    <a href="//<?php echo $_SERVER['SERVER_NAME']; ?>">Кухни цены</a>

                </div>


            </div>

        </div> /.es18_bg -->

        <div class="template es21_balcony" style="background-color: #fff;">
            <div class="container">
                <div class="flex-wrapper">
                    <div class="item"> Остекление <br>    
                        балконов</div>
                    <div class="item">Отделка <br>
                        балконов</div>
                    <div class="item">Готовые  <br>
                        балконы</div>
                    <div class="item">Цены <br>
                         на балконы</div>
                </div>   
            </div>
        </div>