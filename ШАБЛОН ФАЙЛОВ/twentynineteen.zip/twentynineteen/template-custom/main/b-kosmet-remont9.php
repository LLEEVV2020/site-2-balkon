<div class="b-kosmet-remont">
    <div class="container">

        <div class="flex-container">
            <div class="img-block item">
                <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/b-kosmet-remont.png" />
                <span>шкаф купе от 5000 р.</span>
            </div>

            <div class="text-block item">
                <div class="h2">ШКАФ МЕЧТЫ ЗА <span>5 ДНЕЙ</span>? НЕТ НИЧЕГО НЕВОЗМОЖНОГО!</div>
                <div class="b-kosmet-remont__block">

                    <div class="b-kosmet-remont__item ico1">Доставка</div>
                    <div class="b-kosmet-remont__item ico3">Минимальный уровень шума</div>
                    <div class="b-kosmet-remont__item ico2">Отсутствие пыли и мусора</div>
                    <div class="b-kosmet-remont__item ico4">Демократичная цена</div>

                </div>
            </div>

        </div>
    </div>
</div>