        <div class="template es2_balcons finishing_balconies_calc">
        
            <script>
		  
                // КРЫША
                stoim_1_1 = 800; //Гофролист
                  stoim_1_2 = 1100; //Ондулин
                  stoim_1_3 = 0;   //Без крыши
      
      
                  // ТИП ОСТЕКЛЕНИЯ
                  stoim_2_1 = 2050; //Раздвижной
                  stoim_2_2 = 2550; //Распашной
                  stoim_2_3 = 0;    //Без остекления
          
                  
                  // ВНЕШНЯЯ ОТДЕЛКА
                  stoim_3_1 = 1200; //Гафролист
                  stoim_3_2 = 440; //Сайдинг
                  stoim_3_3 = 0;   //Без внешней отделки
                  
                  
                  // ОТДЕЛКА СТЕН						
                  stoim_4_1 = 600; //ПФХ вагонка
                  stoim_4_2 = 700; //ПВХ панель
                  stoim_4_3 = 0;   //Без отделки
                      
                  
                  // ШКАФ НА БАЛКОН						
                  stoim_5_1 = 1200; //Тумба
                  stoim_5_2 = 1700; //Распашной
                  stoim_5_3 = 2250; //Раздвижной
                  stoim_5_4 = 0;   //Без шкафа
                  
                  
                  // НАСТИЛ ПОЛА						
                  stoim_6_1 = 400; //Линолиум
                  stoim_6_2 = 600; //Ламинат
                  stoim_6_3 = 800; //Доска
                  stoim_6_4 = 0;   //Без отделки
                      
              </script>
      
      
     
            <div class="container">
            <!-- $$$$$$$ -->
            <!-- $$$$$$$ -->
            <!-- $$$$$$$ -->

            <div class="h2">
                <script></script>
                <i id="akcia" style="font-style: normal;"></i>
                ЛУЧШИЕ ЦЕНЫ НА БАЛКОНЫ В МОСКВЕ
            </div>
            <div class="text">"Балконы Цены" - компания,которая предлагает услуги по утеплению и отделке балконов и лоджий в Москве уже более 10 лет! За это время нами было реализовано свыше 13 000 проектов. Высокий уровень качества продукции и отсутствие недочетов при монтаже являются визитной карточкой компании.</div>
            <!-- $$$$$$$ -->
            <!-- $$$$$$$ -->
            <!-- $$$$$$$ -->


            <div class="calc_otdelka">						
                  
                  
                <div class="calc_otdelka__left">
                    <!--ОТДЕЛКА стен-->
                    <div class="yellow_plash_bg red-button"><div class="plash_line_4"></div>ОТДЕЛКА стен</div>
                    <div class="container-fluid  wall_decoration">
                        <div class=" param_4_block_1 flex-wrap-block">
                            
                            <div class="flex-wrap-mini">
                                <div class="circle param_4 param_4_1_1 param_4_1_1act"></div>
                                <div class="circle param_4 param_4_1_2"></div>
                                <div class="param_4 circle param_4_1_3"></div>
                                <div class="circle param_4 param_4_1_4"></div>
                            </div>
                            
                            <div class="block-right">
                                
                                <div class="param_4_link param_4_link_act">ПВХ вагонка</div>
                                <div class="param_4_link param_4_link2">ПВХ панель</div>
                                <div class="param_no_4 param_no">Без отделки</div>
                            </div>
                        </div>
                        
                        
                        <div class=" param_4_block_2 flex-wrap-block">
                            
                            <div class="flex-wrap-mini">
                                <div class="circle param_4 circle param_4_2_1 param_4_2_1act"></div>
                                <div class="circle param_4 param_4_2_2"></div>
                                <div class="circle param_4 param_4_2_3"></div>
                                <div class="circle param_4 param_4_2_4"></div>
                            </div>
                            
                            <div class="block-right">
                                
                                <div class="param_4_link param_4_link1">ПВХ вагонка</div>
                                <div class="param_4_link param_4_link_act">ПВХ панель</div>
                                <div class="param_no_4 param_no">Без отделки</div>
                            </div>
                        </div>
                        
                    </div>

                    <!--Тип остекления-->
                    <div class="yellow_plash_bg red-button"><div class="plash_line_2"></div>Тип остекления</div>
                    <div class="container-fluid  glazing_type">
                        <div class="flex-wrap">
                            <div class="circle param_2 param_2_1"><span>Раздвижной</span></div>
                            <div class="circle param_2 param_2_2"><span>Распашной</span></div>
                            <div class="circle param_no_2 param_no param_no_act"><span>Без остекления</span></div>
                        </div>
                        
                    </div>

                    
                    
                    
                    
                    <div class="yellow_plash_bg red-button"><div class="plash_line_3"></div>Внешняя отделка</div>
                    <div class="container-fluid  exterior_finish">
                        <div class="flex-wrap">
                            <div class="circle param_3 circle param_3_1"><span>Гафролист</span></div>
                            <div class="circle param_3 param_3_2"><span>Сайдинг</span></div>
                            <div class="circle param_no_3 param_no param_no_act"><span>Без внешней отделки</span></div>
                        </div>
                        
                    </div>
                    
                </div><!-- /.calc_otdelka__left -->
                
                
                <div class="calc_otdelka__right">
                    
                    <div class="yellow_plash_bg red-button"><div class="plash_line_1"></div>Крыша на балкон</div>
                    <div class="container-fluid balcony_roof">
                        <div class="flex-wrap">
                            <div class="circle scale param_1 param_1_1 param_1_1act"><span>Гафролист</span>   </div>
                            <div class="circle scale param_1 param_1_2"><span>Ондулин</span></div>
                            
                            <div class="circle param_no_1 param_no"><span>Без крыши</span></div>
                        </div>
                        <div class="row">
                        </div>
                    </div>
                    
                    
                    <div class="yellow_plash_bg red-button"><div class="plash_line_5"></div>ШКАФ на балкон</div>
                    <div class="container-fluid   cabinet_balcony">
                        <div class="flex-wrap">
                            <div class="circle param_5 param_5_1"><span>Тумба</span></div>
                            <div class="circle param_5 param_5_2"><span>Распашной</span></div>
                            <div class="circle param_5 param_5_3"><span>Купе</span></div>
                            <div class="circle param_no_5 param_no param_no_act"><span>Без шкафа</span></div>
                        </div>
                        
                    </div>
                    
                    <div class="yellow_plash_bg red-button"><div class="plash_line_6"></div>НАСТИЛ ПОЛА</div>
                    <div class="container-fluid">
                        <div class=" param_6_block_1 flex-wrap-block">
                            
                            <div class="flex-wrap-mini">
                                <div class="circle param_6 param_6_1_1 param_6_1_1act"></div>
                                <div class="circle param_6 param_6_1_2"></div>
                                <div class="circle param_6 param_6_1_3"></div>
                                <div class="circle param_6 param_6_1_4"></div>
                            </div>
                            
                            <div class="block-right">
                                
                                <div class="param_6_link param_6_link_act">Линолеум</div>
                                <div class="param_6_link param_6_link2">Ламинат</div>
                                <div class="param_6_link param_6_link3">Доска </div>
                            </div>
                        </div>
                        
                        
                        <div class=" param_6_block_2 flex-wrap-block">
                            
                            <div class="flex-wrap-mini">
                                <div class="circle param_6 circle param_6_2_1 param_6_2_1act"></div>
                                <div class="circle param_6 param_6_2_2"></div>
                                <div class="circle param_6 param_6_2_3"></div>
                                <div class="circle param_6 param_6_2_4"></div>
                            </div>
                            
                            <div class="block-right">
                                
                                <div class="param_6_link param_6_link1">Линолеум</div>
                                <div class="param_6_link param_6_link_act">Ламинат</div>
                                <div class="param_6_link param_6_link3">Доска </div>
                            </div>
                        </div>
                        
                        <div class=" param_6_block_3 flex-wrap-block">
                            <div class="flex-wrap-mini">
                                
                                <div class="col-xs-12"><div class="param_6 param_6_3_1 param_6_3_1act"></div></div>
                                
                            </div>
                            <div class="block-right">
                                
                                <div class="param_6_link param_6_link1">Линолеум</div>
                                <div class="param_6_link param_6_link2">Ламинат</div>
                                <div class="param_6_link param_6_link_act">Доска </div>
                            </div>
                        </div>
                        
                        
                        
                        <div class="row" style="position: absolute; left: -200vw;">
                            <div class="col-xs-12 param_no_a"><div class="param_no_6 param_no">Без отделки</div></div>
                        </div>
                    </div>
    
                    
                    
                    
                </div><!-- /.calc_otdelka__right -->
                
                
                <div class="calc_otdelka__center">
                    
                    
                    <!-- крыша -->
                    <div class="calc_1"></div>
                    
                    <!-- наружная отделка -->
                    <div class="calc_3"></div>
                                                    
                    <!-- пол -->
                    <div class="calc_6"></div>
                    
                    <!-- стены -->
                    <div class="calc_4"></div>
                    
                    
                    
                    <!-- основа -->
                    <div class="calc_osnova"></div>
                    
                    <!-- остекление -->
                    <div class="calc_2"> </div>
                    
                    <!-- пол бетон -->
                    <div class="calc_6_no"></div>
                    
                    <!-- стены бетон -->
                    <div class="calc_4_no"></div>
                    
                    <!-- шкафы -->
                    <div class="calc_5"></div>
                    
                    
                    
    
                    <div class="tsena_base_bg_block">
                        <div class="tsena_base_bg">
                            <div class="costonsale">Цена по акции</div>
                            
                            <div class="tsena_base_cost"><span>8900</span> </div>
                            
                            <div class="only15days">Только 7 дней!</div>
                        </div>
                    </div>
                    
                    
    
                    
                </div><!-- /.calc_otdelka__center -->
                
                
                
                <div class="calc_otdelka__right_2">
          
<!--<form onsubmit="yaCounter37363900.reachGoal('zayavka'); return true;" action="form9.php" method="POST">
      
                    <div class="input_bg"><input type="text" placeholder="Телефон" class="phonemask" required name="tel" id="form_text_20"/></div>
                    
                    
                    
    <center><input type="submit" value="ЗАКАЗАТЬ СО СКИДКОЙ" style="font-size: 20px; cursor: pointer; text-decoration: none; padding:11px 47px; color:#ffffff; background-color:#e62929; border-radius:5px; border: 2px solid #9e0303;"></center>
    
    </form>				
-->       
<form action="php/mail.php" method="POST">
    <input type="hidden" name="lang" value="Бесплатная консультация">
    <div class="form-group_input form-group">
        <input type="text" placeholder="Ваш телефон" class="phonemask" data-validation="required" id="form_text_10" name="phone" value="" size="0">
    </div>
    <button type="submit" class="red-pink-button">ЗАКАЗАТЬ СО СКИДКОЙ</button>
</form>                  
                                    

                </div><!-- /.calc_otdelka__right_2 -->
                
                
                
                <div class="calc_otdelka__left_2 installment_plan">
                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/null_proc.png" alt="" />
                    <div class="wrap">
                        <span class="calc_otdelka__left_2_zag">Рассрочка 0%</span> 
                
                        <span class="calc_otdelka__left_2_text">Воспользуйтесь беспроцентной рассрочкой
        на 12 месяцев.</span>
                    </div>

                </div><!-- /.calc_otdelka__left_2 -->
                
                </div></div><!-- /.calc_otdelka -->
            </div>
            
      
            <script>
      
              //объявляем переменные
              costfin = 0; 
              stoim1 = stoim_1_1;
              stoim2 = stoim_2_3; 
              stoim3 = stoim_3_3; 
              stoim4 = stoim_4_1;
              stoim5 = stoim_5_4;
              stoim6 = stoim_6_1;
                
                
                
                $(document).ready(function() {
                    
                    
                    
                    
                    change_price_otdelka();
      
                    
                    function change_price_otdelka()
                          {
                              costfin = stoim1 + stoim2 + stoim3 + stoim4 + stoim5 + stoim6;
                              costfin = Math.round(costfin); // округляем до целого
                              $('.tsena_base_cost span').html(costfin); // выводим финальную стоимость
                          }	// конец  change_price_otdelka()
                    
                    
                    // roof start
                    $('.param_1_1').click(function() {
                        $('.param_1_2').removeClass('param_1_2act');
                        $('.param_no_1').removeClass('param_no_act');
                        $('.param_1_1').addClass('param_1_1act');
                        $('.calc_1').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_1_1.png)");
                          $('.calc_1').css("background-size","cover");
                          
                          stoim1 = stoim_1_1;
                          change_price_otdelka();
                    });
                    
                    $('.param_1_2').click(function() {
                        $('.param_1_1').removeClass('param_1_1act');
                        $('.param_no_1').removeClass('param_no_act');
                        $('.param_1_2').addClass('param_1_2act');	
                        $('.calc_1').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_1_2.png)");
                        $('.calc_1').css("background-size","cover");
                        
                        stoim1 = stoim_1_2;
                        change_price_otdelka();
                    });
                    
                    $('.param_no_1').click(function() {
                        $('.param_1_1').removeClass('param_1_1act');
                        $('.param_1_2').removeClass('param_1_2act');
                        $('.param_no_1').addClass('param_no_act');	
                        $('.calc_1').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_1_no.png)");
                        $('.calc_1').css("background-size","cover");
                        
                        stoim1 = stoim_1_3;
                        change_price_otdelka();
                    });
                    // roof end
                    
                    // type of window start
                    $('.param_2_1').click(function() {
                        $('.param_2_2').removeClass('param_2_2act');
                        $('.param_no_2').removeClass('param_no_act');
                        $('.param_2_1').addClass('param_2_1act');
                        $('.calc_2').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_2_1.png)");
                        $('.calc_2').css("background-size","cover");
                        
                        stoim2 = stoim_2_1;
                        change_price_otdelka();
                    });
                    
                    $('.param_2_2').click(function() {
                        $('.param_2_1').removeClass('param_2_1act');
                        $('.param_no_2').removeClass('param_no_act');
                        $('.param_2_2').addClass('param_2_2act');	
                        $('.calc_2').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_2_2.png)");
                        $('.calc_2').css("background-size","cover");
                        
                        stoim2 = stoim_2_2;
                        change_price_otdelka();
                    });
                    
                    $('.param_no_2').click(function() {
                        $('.param_2_1').removeClass('param_2_1act');
                        $('.param_2_2').removeClass('param_2_2act');
                        $('.param_no_2').addClass('param_no_act');	
                        $('.calc_2').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_2_no.png)");
                        $('.calc_2').css("background-size","cover");
                        
                        stoim2 = stoim_2_3;
                        change_price_otdelka();
                    });
                    // type of window end
                    
                    // outside start
                    $('.param_3_1').click(function() {
                        $('.param_3_2').removeClass('param_3_2act');
                        $('.param_no_3').removeClass('param_no_act');
                        $('.param_3_1').addClass('param_3_1act');
                        $('.calc_3').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_3_1.png)");
                        $('.calc_3').css("background-size","cover");
                        
                        stoim3 = stoim_3_1;
                        change_price_otdelka();
                    });
                    
                    $('.param_3_2').click(function() {
                        $('.param_3_1').removeClass('param_3_1act');
                        $('.param_no_3').removeClass('param_no_act');
                        $('.param_3_2').addClass('param_3_2act');	
                        $('.calc_3').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_3_2.png)");
                        $('.calc_3').css("background-size","cover");
                        
                        stoim3 = stoim_3_2;
                        change_price_otdelka();
                    });
                    
                    $('.param_no_3').click(function() {
                        $('.param_3_1').removeClass('param_3_1act');
                        $('.param_3_2').removeClass('param_3_2act');
                        $('.param_no_3').addClass('param_no_act');	
                        $('.calc_3').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_3_no.png)");
                        $('.calc_3').css("background-size","cover");	
                        
                        stoim3 = stoim_3_3;
                        change_price_otdelka();
                    });
                    // outside end
                    
                    // inside start
                    $('.param_4_1_1').click(function() {
                        $('.param_4_1_2').removeClass('param_4_1_2act');
                        $('.param_4_1_3').removeClass('param_4_1_3act');
                        $('.param_4_1_4').removeClass('param_4_1_4act');
                        $('.param_no_4').removeClass('param_no_act');
                        $('.param_4_1_1').addClass('param_4_1_1act');
                        $('.calc_4').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_4_1_1.png)");
                        $('.calc_4').css("background-size","cover");
                        $('.calc_4_no').css("background","none");
                        stoim4 = stoim_4_1;
                        change_price_otdelka();
                    });
                    
                    $('.param_4_1_2').click(function() {
                        $('.param_4_1_1').removeClass('param_4_1_1act');
                        $('.param_4_1_3').removeClass('param_4_1_3act');
                        $('.param_4_1_4').removeClass('param_4_1_4act');
                        $('.param_no_4').removeClass('param_no_act');
                        $('.param_4_1_2').addClass('param_4_1_2act');	
                        $('.calc_4').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_4_1_2.png)");
                        $('.calc_4').css("background-size","cover");
                        $('.calc_4_no').css("background","none");
                        stoim4 = stoim_4_1;
                        change_price_otdelka();
                    });
                    
                    $('.param_4_1_3').click(function() {
                        $('.param_4_1_1').removeClass('param_4_1_1act');
                        $('.param_4_1_2').removeClass('param_4_1_2act');
                        $('.param_4_1_4').removeClass('param_4_1_4act');
                        $('.param_no_4').removeClass('param_no_act');
                        $('.param_4_1_3').addClass('param_4_1_3act');	
                        $('.calc_4').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_4_1_3.png)");
                        $('.calc_4').css("background-size","cover");
                        $('.calc_4_no').css("background","none");
                        stoim4 = stoim_4_1;
                        change_price_otdelka();
                    });
                    
                    $('.param_4_1_4').click(function() {
                        $('.param_4_1_1').removeClass('param_4_1_1act');
                        $('.param_4_1_2').removeClass('param_4_1_2act');
                        $('.param_4_1_3').removeClass('param_4_1_3act');
                        $('.param_no_4').removeClass('param_no_act');
                        $('.param_4_1_4').addClass('param_4_1_4act');	
                        $('.calc_4').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_4_1_4.png)");
                        $('.calc_4').css("background-size","cover");
                        $('.calc_4_no').css("background","none");
                        stoim4 = stoim_4_1;
                        change_price_otdelka();
                    });
                    
                    
                    
                    
                    
                    
                    $('.param_4_2_1').click(function() {
                        $('.param_4_2_2').removeClass('param_4_2_2act');
                        $('.param_4_2_3').removeClass('param_4_2_3act');
                        $('.param_4_2_4').removeClass('param_4_2_4act');
                        $('.param_no_4').removeClass('param_no_act');
                        $('.param_4_2_1').addClass('param_4_2_1act');
                        $('.calc_4').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_4_2_1.png)");
                        $('.calc_4').css("background-size","cover");
                        $('.calc_4_no').css("background","none");
                        stoim4 = stoim_4_2;
                        change_price_otdelka();
                    });
                    
                    $('.param_4_2_2').click(function() {
                        $('.param_4_2_1').removeClass('param_4_2_1act');
                        $('.param_4_2_3').removeClass('param_4_2_3act');
                        $('.param_4_2_4').removeClass('param_4_2_4act');
                        $('.param_no_4').removeClass('param_no_act');
                        $('.param_4_2_2').addClass('param_4_2_2act');	
                        $('.calc_4').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_4_2_2.png)");
                        $('.calc_4').css("background-size","cover");
                        $('.calc_4_no').css("background","none");
                        stoim4 = stoim_4_2;
                        change_price_otdelka();
                    });
                    
                    $('.param_4_2_3').click(function() {
                        $('.param_4_2_1').removeClass('param_4_2_1act');
                        $('.param_4_2_2').removeClass('param_4_2_2act');
                        $('.param_4_2_4').removeClass('param_4_2_4act');
                        $('.param_no_4').removeClass('param_no_act');
                        $('.param_4_2_3').addClass('param_4_2_3act');	
                        $('.calc_4').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_4_2_3.png)");
                        $('.calc_4').css("background-size","cover");
                        $('.calc_4_no').css("background","none");
                        stoim4 = stoim_4_2;
                        change_price_otdelka();
                    });
                    
                    $('.param_4_2_4').click(function() {
                        $('.param_4_2_1').removeClass('param_4_2_1act');
                        $('.param_4_2_2').removeClass('param_4_2_2act');
                        $('.param_4_2_3').removeClass('param_4_2_3act');
                        $('.param_no_4').removeClass('param_no_act');
                        $('.param_4_2_4').addClass('param_4_2_4act');	
                        $('.calc_4').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_4_2_4.png)");
                        $('.calc_4').css("background-size","cover");
                        $('.calc_4_no').css("background","none");
                        stoim4 = stoim_4_2;
                        change_price_otdelka();
                    });
                    
                    
                    $('.param_no_4').click(function() {
                        $('.param_4_1_1').removeClass('param_4_1_1act');
                        $('.param_4_1_2').removeClass('param_4_1_2act');
                        $('.param_4_1_3').removeClass('param_4_1_3act');
                        $('.param_4_1_4').removeClass('param_4_1_4act');
                          $('.param_4_2_1').removeClass('param_4_2_1act');
                        $('.param_4_2_2').removeClass('param_4_2_2act');
                        $('.param_4_2_3').removeClass('param_4_2_3act');
                        $('.param_4_2_4').removeClass('param_4_2_4act');
                        $('.param_no_4').addClass('param_no_act');	
                        $('.calc_4_no').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_4_no.png)");	
                        $('.calc_4_no').css("background-size","cover");
                        
                        stoim4 = stoim_4_3;
                        change_price_otdelka();
                    });
                    
                    $('.param_4_link1').click(function() {
                        $('.param_4_1_2').removeClass('param_4_1_2act');
                        $('.param_4_1_3').removeClass('param_4_1_3act');
                        $('.param_4_1_4').removeClass('param_4_1_4act');
                        $('.param_no_4').removeClass('param_no_act');
                        $('.param_4_1_1').addClass('param_4_1_1act');
                        $('.calc_4').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_4_1_1.png)");
                        $('.calc_4').css("background-size","cover");
                        $('.param_4_block_2').css("display","none");
                        $('.param_4_block_1').css("display","block");
                        $('.calc_4_no').css("background","none");
                        stoim4 = stoim_4_1;
                        change_price_otdelka();
                    });
                    
                    $('.param_4_link2').click(function() {
                        $('.param_4_2_2').removeClass('param_4_2_2act');
                        $('.param_4_2_3').removeClass('param_4_2_3act');
                        $('.param_4_2_4').removeClass('param_4_2_4act');
                        $('.param_no_4').removeClass('param_no_act');
                        $('.param_4_2_1').addClass('param_4_2_1act');
                        $('.calc_4').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_4_2_1.png)");
                        $('.calc_4').css("background-size","cover");
                        $('.param_4_block_1').css("display","none");
                        $('.param_4_block_2').css("display","block");
                        $('.calc_4_no').css("background","none");
                        stoim4 = stoim_4_2;
                        change_price_otdelka();
                    });
                    // inside end
                    
                    // furniture start
                    $('.param_5_1').click(function() {
                        $('.param_5_2').removeClass('param_5_2act');
                        $('.param_5_3').removeClass('param_5_3act');
                        $('.param_no_5').removeClass('param_no_act');
                        $('.param_5_1').addClass('param_5_1act');
                        $('.calc_5').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_5_1.png)");
                        $('.calc_5').css("background-size","cover");
                        
                        stoim5 = stoim_5_1;
                        change_price_otdelka();
                    });
                    
                    $('.param_5_2').click(function() {
                        $('.param_5_1').removeClass('param_5_1act');
                        $('.param_5_3').removeClass('param_5_3act');
                        $('.param_no_5').removeClass('param_no_act');
                        $('.param_5_2').addClass('param_5_2act');	
                        $('.calc_5').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_5_2_.png)");
                        $('.calc_5').css("background-size","cover");
                        
                        stoim5 = stoim_5_2;
                        change_price_otdelka();
                    });
                    
                    $('.param_5_3').click(function() {
                        $('.param_5_1').removeClass('param_5_1act');
                        $('.param_5_2').removeClass('param_5_2act');
                        $('.param_no_5').removeClass('param_no_act');
                        $('.param_5_3').addClass('param_5_3act');	
                        $('.calc_5').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_5_3_.png)");
                        $('.calc_5').css("background-size","cover");
                        
                        stoim5 = stoim_5_3;
                        change_price_otdelka();
                    });
                    
                    $('.param_no_5').click(function() {
                        $('.param_5_1').removeClass('param_5_1act');
                        $('.param_5_2').removeClass('param_5_2act');
                        $('.param_5_3').removeClass('param_5_3act');
                        $('.param_no_5').addClass('param_no_act');	
                        $('.calc_5').css("background","none");	
                        
                        stoim5 = stoim_5_4;
                        change_price_otdelka();
                    });
                    // furniture end
                    
                    
                    
                    // floor start
                    $('.param_6_1_1').click(function() {
                        $('.param_6_1_2').removeClass('param_6_1_2act');
                        $('.param_6_1_3').removeClass('param_6_1_3act');
                        $('.param_6_1_4').removeClass('param_6_1_4act');
                        $('.param_no_6').removeClass('param_no_act');
                        $('.param_6_1_1').addClass('param_6_1_1act');
                        $('.calc_6').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_6_1_1.png)");
                        $('.calc_6').css("background-size","cover");
                        $('.calc_6_no').css("background","none");
                        stoim6 = stoim_6_1;
                        change_price_otdelka();
                    });
                    
                    $('.param_6_1_2').click(function() {
                        $('.param_6_1_1').removeClass('param_6_1_1act');
                        $('.param_6_1_3').removeClass('param_6_1_3act');
                        $('.param_6_1_4').removeClass('param_6_1_4act');
                        $('.param_no_6').removeClass('param_no_act');
                        $('.param_6_1_2').addClass('param_6_1_2act');	
                        $('.calc_6').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_6_1_2.png)");
                        $('.calc_6').css("background-size","cover");
                        $('.calc_6_no').css("background","none");
                        stoim6 = stoim_6_1;
                        change_price_otdelka();
                    });
                    
                    $('.param_6_1_3').click(function() {
                        $('.param_6_1_1').removeClass('param_6_1_1act');
                        $('.param_6_1_2').removeClass('param_6_1_2act');
                        $('.param_6_1_4').removeClass('param_6_1_4act');
                        $('.param_no_6').removeClass('param_no_act');
                        $('.param_6_1_3').addClass('param_6_1_3act');	
                        $('.calc_6').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_6_1_3.png)");
                        $('.calc_6').css("background-size","cover");
                        $('.calc_6_no').css("background","none");
                        stoim6 = stoim_6_1;
                        change_price_otdelka();
                    });
                    
                    $('.param_6_1_4').click(function() {
                        $('.param_6_1_1').removeClass('param_6_1_1act');
                        $('.param_6_1_2').removeClass('param_6_1_2act');
                        $('.param_6_1_3').removeClass('param_6_1_3act');
                        $('.param_no_6').removeClass('param_no_act');
                        $('.param_6_1_4').addClass('param_6_1_4act');	
                        $('.calc_6').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_6_1_4.png)");
                        $('.calc_6').css("background-size","cover");
                        $('.calc_6_no').css("background","none");
                        stoim6 = stoim_6_1;
                        change_price_otdelka();
                    });
                    
                    
                    $('.param_6_2_1').click(function() {
                        $('.param_6_2_2').removeClass('param_6_2_2act');
                        $('.param_6_2_3').removeClass('param_6_2_3act');
                        $('.param_6_2_4').removeClass('param_6_2_4act');
                        $('.param_no_6').removeClass('param_no_act');
                        $('.param_6_2_1').addClass('param_6_2_1act');
                        $('.calc_6').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_6_2_2.png)");
                        $('.calc_6').css("background-size","cover");
                        $('.calc_6_no').css("background","none");
                        stoim6 = stoim_6_2;
                        change_price_otdelka();
                    });
                    
                    $('.param_6_2_2').click(function() {
                        $('.param_6_2_1').removeClass('param_6_2_1act');
                        $('.param_6_2_3').removeClass('param_6_2_3act');
                        $('.param_6_2_4').removeClass('param_6_2_4act');
                        $('.param_no_6').removeClass('param_no_act');
                        $('.param_6_2_2').addClass('param_6_2_2act');	
                        $('.calc_6').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_6_2_1.png)");
                        $('.calc_6').css("background-size","cover");
                        $('.calc_6_no').css("background","none");
                        stoim6 = stoim_6_2;
                        change_price_otdelka();
                    });
                    
                    $('.param_6_2_3').click(function() {
                        $('.param_6_2_1').removeClass('param_6_2_1act');
                        $('.param_6_2_2').removeClass('param_6_2_2act');
                        $('.param_6_2_4').removeClass('param_6_2_4act');
                        $('.param_no_6').removeClass('param_no_act');
                        $('.param_6_2_3').addClass('param_6_2_3act');	
                        $('.calc_6').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_6_2_3.png)");
                        $('.calc_6').css("background-size","cover");
                        $('.calc_6_no').css("background","none");
                        stoim6 = stoim_6_2;
                        change_price_otdelka();
                    });
                    
                    $('.param_6_2_4').click(function() {
                        $('.param_6_2_1').removeClass('param_6_2_1act');
                        $('.param_6_2_2').removeClass('param_6_2_2act');
                        $('.param_6_2_3').removeClass('param_6_2_3act');
                        $('.param_no_6').removeClass('param_no_act');
                        $('.param_6_2_4').addClass('param_6_2_4act');	
                        $('.calc_6').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_6_2_4.png)");
                        $('.calc_6').css("background-size","cover");
                        $('.calc_6_no').css("background","none");
                        stoim6 = stoim_6_2;
                        change_price_otdelka();
                    });
                    
                    
                    
                    $('.param_6_3_1').click(function() {
                        $('.param_no_6').removeClass('param_no_act');
                        $('.param_6_3_1').addClass('param_6_3_1act');	
                        $('.calc_6').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_6_3_1.png)");
                        $('.calc_6').css("background-size","cover");
                        $('.calc_6_no').css("background","none");
                        stoim6 = stoim_6_3;
                        change_price_otdelka();
                    });
                    
                    
                    
                    
                    $('.param_no_6').click(function() {
                        $('.param_6_1_1').removeClass('param_6_1_1act');
                        $('.param_6_1_2').removeClass('param_6_1_2act');
                        $('.param_6_1_3').removeClass('param_6_1_3act');
                        $('.param_6_1_4').removeClass('param_6_1_4act');
                          $('.param_6_2_1').removeClass('param_6_2_1act');
                        $('.param_6_2_2').removeClass('param_6_2_2act');
                        $('.param_6_2_3').removeClass('param_6_2_3act');
                        $('.param_6_2_4').removeClass('param_6_2_4act');
                        $('.param_6_3_1').removeClass('param_6_3_1act');
                        $('.param_no_6').addClass('param_no_act');	
                        $('.calc_6_no').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_6_no.png)");	
                        $('.calc_6_no').css("background-size","cover");
                        
                        stoim6 = stoim_6_4;
                        change_price_otdelka();
                    });
                    
                    $('.param_6_link1').click(function() {
                        $('.param_6_1_2').removeClass('param_6_1_2act');
                        $('.param_6_1_3').removeClass('param_6_1_3act');
                        $('.param_6_1_4').removeClass('param_6_1_4act');
                        $('.param_no_6').removeClass('param_no_act');
                        $('.param_6_1_1').addClass('param_6_1_1act');
                        $('.calc_6').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_6_1_1.png)");
                        $('.calc_6').css("background-size","cover");
                        $('.param_6_block_2').css("display","none");
                        $('.param_6_block_3').css("display","none");
                        $('.param_6_block_1').css("display","block");
                        $('.calc_6_no').css("background","none");
                        stoim6 = stoim_6_1;
                        change_price_otdelka();
                    });
                    
                    $('.param_6_link2').click(function() {
                        $('.param_6_2_2').removeClass('param_6_2_2act');
                        $('.param_6_2_3').removeClass('param_6_2_3act');
                        $('.param_6_2_4').removeClass('param_6_2_4act');
                        $('.param_no_6').removeClass('param_no_act');
                        $('.param_6_2_1').addClass('param_6_2_1act');
                        $('.calc_6').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_6_2_2.png)");
                        $('.calc_6').css("background-size","cover");
                        $('.param_6_block_1').css("display","none");
                        $('.param_6_block_3').css("display","none");
                        $('.param_6_block_2').css("display","block");
                        $('.calc_6_no').css("background","none");
                        stoim6 = stoim_6_2;
                        change_price_otdelka();
                    });
                    
                    $('.param_6_link3').click(function() {
                        $('.param_no_6').removeClass('param_no_act');
                        $('.param_6_3_1').addClass('param_6_3_1act');
                        $('.calc_6').css("background","url(//<?php echo $_SERVER['SERVER_NAME']; ?>/img/calc_otdelka/calc_6_3_1.png)");
                        $('.calc_6').css("background-size","cover");
                        $('.param_6_block_1').css("display","none");
                        $('.param_6_block_2').css("display","none");
                        $('.param_6_block_3').css("display","block");
                        $('.calc_6_no').css("background","none");	
                        stoim6 = stoim_6_3;
                        change_price_otdelka();
                    });
                    // floor end
                    
                });
            </script>

        