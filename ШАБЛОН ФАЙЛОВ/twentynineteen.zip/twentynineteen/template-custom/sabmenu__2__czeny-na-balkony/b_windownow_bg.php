<div class="b_windownow_bg b_windownow_bg_temp2"  >

        <div class="container">

            <div class="flex-container">
                <div class="b_windownow_man"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/b_windownow_man.png" alt=""></div>
                <div class="b_windownow_block">
                    <h4>ШКАФ СЕЙЧАС - ДЕНЬГИ ПОТОМ</h4>
                    <div class="flex-block">
                        <div class="b_windownow_proc"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/b_windownow_proc.png" alt=""></div>

                        <div class="b_windownow_text">
                            <p>Рассрочка <br> без предоплаты</p>

                            <a href="remont-kvartir-rassrochka/index.html" class="b_windownow__btn">Узнать
                                подробности</a>

                        </div>
                    </div>

                </div>

            </div>



        </div><!-- /.container -->

    </div>